
import GestionPablo from '../components/GestionPablo';
export default function Home() {
  return <GestionPablo />;
}
